<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Preguntas;
use Faker\Generator as Faker;

$factory->define(Preguntas::class, function (Faker $faker) {
    return [
        //
    ];
});
