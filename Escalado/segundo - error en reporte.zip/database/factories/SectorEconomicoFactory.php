<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sector_economico;
use Faker\Generator as Faker;

$factory->define(Sector_economico::class, function (Faker $faker) {
    return [
        //
    ];
});
