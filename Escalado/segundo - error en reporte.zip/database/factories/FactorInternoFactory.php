<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FactorInterno;
use Faker\Generator as Faker;

$factory->define(FactorInterno::class, function (Faker $faker) {
    return [
        //
    ];
});
