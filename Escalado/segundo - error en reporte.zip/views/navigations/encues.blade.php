{{--<li><a class="nav-link" href="{{ route('home') }}"> {{ __("Informacion") }} </a></li>--}}
{{--<li><a class="nav-link" href=""> {{ __("Informacion") }} </a></li>--}}
@include('navigations.logged')
