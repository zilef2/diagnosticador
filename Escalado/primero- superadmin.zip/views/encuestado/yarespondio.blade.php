<div class="container">
    <div class="row">
        <div class="col-sm">
            <div data-border-width="2" style="transform-origin:center 1px;top:;bottom:;left:;right:;width:40px;height:5px;position:" class="style-jb3n1vqa" ></div>
            <div data-packed="true" data-vertical-text="false" style="width: 251px; pointer-events: none;" class="txtNew" ><h4 class="font_4" style="line-height:1.2em;"><span style="letter-spacing:-0.1em;">
                <div class="alert alert-success" role="alert">
                    ¡Formulario completo!</div></h4></div>
            <div data-packed="true" data-vertical-text="false" style="width: 371px; pointer-events: none;" class="txtNew" ><p class="font_8" style="line-height:1.7em;">
                <span style="letter-spacing:0.02em;">
                    Usted ya respondio la encuesta. Gracias
                </span></p>
                <p class="font_8" style="line-height:1.7em;"><span style="letter-spacing:0.02em;">​</span></p>
{{--                <p class="font_8" style="line-height:1.7em;"><span style="letter-spacing:0.02em;">--}}
{{--                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam consequatur corporis doloribus fugit id nostrum placeat, possimus quo rem repellendus saepe tempore tenetur totam unde voluptatem voluptatum? Atque, inventore..&nbsp;--}}
{{--                    </span></p>--}}
                </div>
            <div  data-align="center" data-disabled="false" data-margin="0" data-should-use-flex="true" data-width="115" data-height="40" style="height: 40px; min-height: 22px; width: 115px;" class="style-jjdz3xj0" data-state="desktop shouldUseFlex center">
                <a href="" target="_self"  class="g-transparent-a style-jjdz3xj0link">
{{--                    <span  class="style-jjdz3xj0label">Para mas informacion comuniquese con </span>--}}
                </a>
            </div>
        </div>
        <div class="col-sm">
            <img src="{{ url('/images/logito.png') }}" height="300px" alt="no Icono">

        </div>


    </div>
</div>
