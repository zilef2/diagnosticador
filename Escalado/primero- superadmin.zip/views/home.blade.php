@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            @if(Auth::user()->is_admin>0)
                @include('admin.Dashboard')
            @else

            <div class="card">
                <div class="card-header">{{ __('MATRIZ EVALUACIÓN DEL FACTOR INTERNO-FUNCIÓN DE PERTENENCIA') }}</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                @if(Auth::user()->activo==0)
                    @include('encuestado.encuesta')
                @else
                    @include('encuestado.yarespondio')
                @endif
                </div>
            </div>
        @endif
        </div>
    </div>
</div>

@endsection
